$(function (context) {
    return function () {

        $('#get-start').click(function() {
            var symbol = document.getElementById("symbol-list").value;
            $.ajax({
                url: "/homepage/lowest/" + symbol,
            }).done(function(content){
                $('#start-date').val(content);
            });
        });

        $('#get-end').click(function() {
            var symbol = document.getElementById("symbol-list").value;
            $.ajax({
                url: "/homepage/highest/" + symbol,
            }).done(function(content){
                $('#end-date').val(content);
            });
        });

    }
}(DMP_CONTEXT.get()))